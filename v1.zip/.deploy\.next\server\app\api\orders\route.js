var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/route.js")
R.c("server/chunks/[root-of-the-server]__271488d7._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_orders_route_actions_9a6edca0.js")
R.m(81585)
module.exports=R.m(81585).exports
